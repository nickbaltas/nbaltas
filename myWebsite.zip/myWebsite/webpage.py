<html>
 <head>
<title>A Simple Webpage</title>
</head>
<body style="background: yellow">
This is a simple webpage.
And I mean <em>really</em> simple.
</body>
</html>

